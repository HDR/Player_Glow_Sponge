package net.minecraft.entity;

import net.minecraft.entity.player.EntityPlayerMP;

public class GlowFix {
    
    public static void setGlowing(EntityPlayerMP player, boolean glowing){
        Entity living=player;
        living.glowing=glowing;
    }    
    
}
